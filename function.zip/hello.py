def lambda_handler(event, context):
    print(event)
    return 'Hello Bank Leumi, I want to join you'
